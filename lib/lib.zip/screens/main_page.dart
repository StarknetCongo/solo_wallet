import 'package:flutter/material.dart';
import 'package:solo_wallet/constants/style.dart';
<<<<<<< HEAD
import 'package:solo_wallet/screens/create_pin.dart';
=======
>>>>>>> 3c69afa0f245e15944b2da14e016b151de67652b
import 'package:solo_wallet/screens/navigationButton_bar.dart';

// ignore: camel_case_types
class Main_page extends StatefulWidget {
  const Main_page({super.key});

  @override
  State<Main_page> createState() => _Main_pageState();
}
<<<<<<< HEAD
=======

>>>>>>> 3c69afa0f245e15944b2da14e016b151de67652b
// ignore: camel_case_types
class _Main_pageState extends State<Main_page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset('assets/reg.avif'),
          Text(
            'Solo wallet',
            style: TitreStyle,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white,
                  backgroundColor: CouleurPrincipale, // Text color
                  shadowColor: Colors.deepPurpleAccent, // Shadow color
                  elevation: 10, // Elevation
<<<<<<< HEAD
                  padding:  const EdgeInsets.symmetric(
=======
                  padding: const EdgeInsets.symmetric(
>>>>>>> 3c69afa0f245e15944b2da14e016b151de67652b
                      horizontal: 70, vertical: 15), // Padding
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10), // Rounded corners
                  ),
                  textStyle: const TextStyle(
                    fontSize: 18, // Text size
                    fontWeight: FontWeight.bold, // Text weight
                  ),
                ),
<<<<<<< HEAD
                   onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                        builder: (context) => const Create_pin()),
                  );
                },
                child:  Text('Create a new account',style: TitreStyleWhite,),
=======
                onPressed: () {
                  // Handle button press
                },
                child: const Text('Create a new account'),
>>>>>>> 3c69afa0f245e15944b2da14e016b151de67652b
              ),
              Padding(
                padding: const EdgeInsets.only(top: 30),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: CouleurPrincipale, // Text color
                    shadowColor: Colors.deepPurpleAccent, // Shadow color
                    elevation: 10, // Elevation
                    padding: const EdgeInsets.symmetric(
                        horizontal: 50, vertical: 15), // Padding
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(10), // Rounded corners
                    ),
                    textStyle: const TextStyle(
                      fontSize: 18, // Text size
                      fontWeight: FontWeight.bold, // Text weight
                    ),
                  ),
                  onPressed: () {
                    // Handle button press
                  },
<<<<<<< HEAD
                  child:  Text('Restore an existing account',style: TitreStyleWhite,),
=======
                  child: const Text('Restore an existing account'),
>>>>>>> 3c69afa0f245e15944b2da14e016b151de67652b
                ),
              ),
              TextButton(
                child: const Text('Skip'),
                onPressed: () {
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(
                        builder: (context) => const Navigation_Page()),
                  );
                },
              )
            ],
          ),
        ],
      ),
    );
  }
}
