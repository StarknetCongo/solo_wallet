import 'package:flutter/material.dart';
<<<<<<< HEAD
import 'package:solo_wallet/screens/create_account.dart';
import 'package:solo_wallet/screens/create_pin.dart';
import 'package:solo_wallet/screens/loading_page.dart';
import 'package:solo_wallet/screens/main_page.dart';
=======

import 'package:solo_wallet/screens/loading_page.dart';
>>>>>>> 3c69afa0f245e15944b2da14e016b151de67652b

void main() {
  // SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
  //     statusBarColor: Colors.transparent,
  //     systemNavigationBarColor: Colors.black));

  // SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
  //     statusBarColor: Colors.transparent,
  //     systemNavigationBarColor: Colors.black));
  return runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Solo Wallet',
      theme: ThemeData(primarySwatch: Colors.blue, fontFamily: 'Google'),
<<<<<<< HEAD
      home:  Main_page(),
=======
      home: const Loading(),
>>>>>>> 3c69afa0f245e15944b2da14e016b151de67652b
    );
  }
}
